railsbridge-slides
==================

Slides and materials for RailsBridge RoR workshop